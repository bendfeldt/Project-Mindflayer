# Claude Code Setup — Consultant Portable Toolkit

Your personal, client-agnostic Claude Code configuration.

## Architecture

```
~/.claude/                              ← GLOBAL (travels with you)
├── CLAUDE.md                           ← Your identity, standards, stack
├── docs/
│   ├── terraform-patterns.md           ← Reference (loaded via @-include)
│   ├── kimball-reference.md            ← Reference (loaded via @-include)
│   └── repo-templates/                 ← Templates for new repos
│       ├── CLAUDE-terraform.md
│       ├── CLAUDE-databricks.md
│       ├── CLAUDE-fabric.md
│       └── CLAUDE-dagster.md
└── skills/                             ← Available in every session
    ├── adr/
    ├── terraform-scaffold/
    └── kimball-model/

~/repos/{client}-{tool}/                ← PER-REPO (thin, client-specific)
└── CLAUDE.md                           ← ~40 lines: platform, prefix, build, branching
```

Claude Code merges both layers automatically. Skills read the repo `CLAUDE.md` to
know which platform they're operating on (Terraform, Databricks, Fabric, Dagster).
If no repo `CLAUDE.md` exists, skills fall back to file-based detection.

## What's Included

**Global config (installed to `~/.claude/`):**
```
CLAUDE.md                                  → Global instructions
docs/terraform-patterns.md                 → Terraform quick reference
docs/kimball-reference.md                  → Kimball modeling quick reference
docs/repo-templates/CLAUDE-terraform.md    → Template for Terraform repos
docs/repo-templates/CLAUDE-databricks.md   → Template for Databricks repos
docs/repo-templates/CLAUDE-fabric.md       → Template for Fabric repos
docs/repo-templates/CLAUDE-dagster.md      → Template for Dagster repos
skills/adr/SKILL.md                        → /adr
skills/terraform-scaffold/SKILL.md         → /terraform-scaffold
skills/terraform-scaffold/references/      → Dagster, ADO, Fabric patterns
skills/kimball-model/SKILL.md              → /kimball-model
```

## Installation

```bash
bash install.sh
```

This installs the global config to `~/.claude/`. It backs up any existing config first.

## Setting Up a New Repo

Templates live in `~/.claude/docs/repo-templates/` — always accessible from any directory:

```bash
# Example: new Fabric repo for PostNord
cp ~/.claude/docs/repo-templates/CLAUDE-fabric.md ~/repos/postnord-fabric/CLAUDE.md
# Then fill in the {placeholders} — client name, prefix, capacity, etc.
```

The repo templates are intentionally thin (~40 lines). They declare what's unique to this
repo — client name, platform, prefix, build commands, branching. Everything else comes from
your global `~/.claude/CLAUDE.md` and the skills. No duplication means no drift.

## How Merging Works

When you run `claude` inside a repo:

1. **`~/.claude/CLAUDE.md`** loads first — your coding standards, commit format,
   architecture principles, compliance awareness
2. **`{repo}/CLAUDE.md`** layers on top — client prefix, platform, build commands,
   environment details, branching strategy
3. **Skills** are available globally — they read both layers to adapt

Example: You're in `~/repos/postnord-fabric/` and type `/kimball-model`.
The skill sees `platform: microsoft-fabric` from the repo CLAUDE.md and generates
Fabric-style DDL (T-SQL views, lakehouse schemas, semantic model hints) instead
of generic SQL.

## Customization

- Edit `~/.claude/CLAUDE.md` to adjust your global preferences
- Add new skills to `~/.claude/skills/{skill-name}/SKILL.md`
- Add reference docs to `~/.claude/docs/` and include them with `@~/.claude/docs/filename.md`
- Create new repo templates for additional tool types as needed
