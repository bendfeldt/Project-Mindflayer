#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== Consultant Toolkit — Cross-Platform Install ==="
echo ""

# Back up existing config
if [ -f ~/.claude/CLAUDE.md ]; then
    BACKUP=~/.claude/CLAUDE.md.bak.$(date +%Y%m%d%H%M%S)
    cp ~/.claude/CLAUDE.md "$BACKUP"
    echo "Backed up existing ~/.claude/CLAUDE.md → $BACKUP"
fi

# Create directories
mkdir -p ~/.claude/docs/repo-templates/settings
mkdir -p ~/.claude/skills/adr
mkdir -p ~/.claude/skills/terraform-scaffold/references
mkdir -p ~/.claude/skills/kimball-model
mkdir -p ~/.claude/skills/setup-repo

# ============================================================
# Global config — install to ALL agent tool locations
# ============================================================
# The source of truth is ~/.claude/CLAUDE.md (Claude Code native path).
# Other tools get a copy at their native location.

cp "$SCRIPT_DIR/CLAUDE.md" ~/.claude/CLAUDE.md
echo "Installed: ~/.claude/CLAUDE.md (Claude Code)"

# Codex CLI — reads ~/.codex/AGENTS.md
mkdir -p ~/.codex
cp "$SCRIPT_DIR/CLAUDE.md" ~/.codex/AGENTS.md
echo "Installed: ~/.codex/AGENTS.md (Codex CLI)"

# Gemini CLI — reads ~/.gemini/GEMINI.md
mkdir -p ~/.gemini
cp "$SCRIPT_DIR/CLAUDE.md" ~/.gemini/GEMINI.md
echo "Installed: ~/.gemini/GEMINI.md (Gemini CLI)"

echo ""
echo "Note: All three files have the same content. Edit ~/.claude/CLAUDE.md"
echo "as the source of truth, then run this installer again to sync."
echo ""

# Global settings — compare and offer to merge if existing
SETTINGS_SRC="$SCRIPT_DIR/docs/repo-templates/settings/settings-global.json"
SETTINGS_DST="$HOME/.claude/settings.json"

if [ ! -f "$SETTINGS_DST" ]; then
    cp "$SETTINGS_SRC" "$SETTINGS_DST"
    echo "Installed global settings.json (permission defaults)"
elif diff -q "$SETTINGS_SRC" "$SETTINGS_DST" > /dev/null 2>&1; then
    echo "Global settings.json is up to date"
else
    echo ""
    echo "Your existing ~/.claude/settings.json differs from the toolkit version."
    echo ""
    diff --unified=3 "$SETTINGS_DST" "$SETTINGS_SRC" || true
    echo ""
    echo "Options:"
    echo "  [k] Keep your current settings (no changes)"
    echo "  [r] Replace with toolkit version (backs up current)"
    echo "  [m] Show both files so you can merge manually"
    echo ""
    read -r -p "Choose [k/r/m]: " choice
    case "$choice" in
        r|R)
            BACKUP="$SETTINGS_DST.bak.$(date +%Y%m%d%H%M%S)"
            cp "$SETTINGS_DST" "$BACKUP"
            cp "$SETTINGS_SRC" "$SETTINGS_DST"
            echo "Replaced settings.json (backup at $BACKUP)"
            ;;
        m|M)
            echo ""
            echo "Current:  $SETTINGS_DST"
            echo "Toolkit:  $SETTINGS_SRC"
            echo ""
            echo "Edit your settings.json manually to merge the changes."
            ;;
        *)
            echo "Kept existing settings.json"
            ;;
    esac
fi

# Reference docs
cp "$SCRIPT_DIR/docs/terraform-patterns.md" ~/.claude/docs/
cp "$SCRIPT_DIR/docs/kimball-reference.md" ~/.claude/docs/

# Repo templates
cp "$SCRIPT_DIR/docs/repo-templates/AGENTS-terraform.md" ~/.claude/docs/repo-templates/
cp "$SCRIPT_DIR/docs/repo-templates/AGENTS-databricks.md" ~/.claude/docs/repo-templates/
cp "$SCRIPT_DIR/docs/repo-templates/AGENTS-fabric.md" ~/.claude/docs/repo-templates/
cp "$SCRIPT_DIR/docs/repo-templates/AGENTS-dagster.md" ~/.claude/docs/repo-templates/

# Settings templates
cp "$SCRIPT_DIR/docs/repo-templates/settings/settings-global.json" ~/.claude/docs/repo-templates/settings/
cp "$SCRIPT_DIR/docs/repo-templates/settings/settings-terraform.json" ~/.claude/docs/repo-templates/settings/
cp "$SCRIPT_DIR/docs/repo-templates/settings/settings-databricks.json" ~/.claude/docs/repo-templates/settings/
cp "$SCRIPT_DIR/docs/repo-templates/settings/settings-fabric.json" ~/.claude/docs/repo-templates/settings/
cp "$SCRIPT_DIR/docs/repo-templates/settings/settings-dagster.json" ~/.claude/docs/repo-templates/settings/

# Cross-tool config templates
mkdir -p ~/.claude/docs/repo-templates/codex
mkdir -p ~/.claude/docs/repo-templates/copilot
cp "$SCRIPT_DIR/docs/repo-templates/codex/config.toml" ~/.claude/docs/repo-templates/codex/
cp "$SCRIPT_DIR/docs/repo-templates/codex/codex.md" ~/.claude/docs/repo-templates/codex/
cp "$SCRIPT_DIR/docs/repo-templates/copilot/copilot-instructions.md" ~/.claude/docs/repo-templates/copilot/

# Skills
cp "$SCRIPT_DIR/.claude/skills/adr/SKILL.md" ~/.claude/skills/adr/
cp "$SCRIPT_DIR/.claude/skills/terraform-scaffold/SKILL.md" ~/.claude/skills/terraform-scaffold/
cp "$SCRIPT_DIR/.claude/skills/terraform-scaffold/references/dagster.md" ~/.claude/skills/terraform-scaffold/references/
cp "$SCRIPT_DIR/.claude/skills/terraform-scaffold/references/azure-devops-pipelines.md" ~/.claude/skills/terraform-scaffold/references/
cp "$SCRIPT_DIR/.claude/skills/terraform-scaffold/references/fabric-modules.md" ~/.claude/skills/terraform-scaffold/references/
cp "$SCRIPT_DIR/.claude/skills/kimball-model/SKILL.md" ~/.claude/skills/kimball-model/
mkdir -p ~/.claude/skills/setup-repo
cp "$SCRIPT_DIR/.claude/skills/setup-repo/SKILL.md" ~/.claude/skills/setup-repo/

echo ""
echo "=== Installed ==="
echo ""
echo "Global config (all tools):"
echo "  ~/.claude/CLAUDE.md              (Claude Code)"
echo "  ~/.codex/AGENTS.md               (Codex CLI)"
echo "  ~/.gemini/GEMINI.md              (Gemini CLI)"
echo "  ~/.claude/settings.json          (Claude Code permissions)"
echo "  ~/.claude/sync-global.sh         (sync config to all tools after edits)"
echo ""
echo "Skills (4 — cross-platform via SKILL.md standard):"
echo "  /setup-repo, /adr, /terraform-scaffold, /kimball-model"
echo ""
echo "Repo templates (in ~/.claude/docs/repo-templates/):"
echo "  AGENTS-{terraform,databricks,fabric,dagster}.md"
echo "  settings/settings-{type}.json    (Claude Code permissions)"
echo "  codex/config.toml + codex.md     (Codex CLI config)"
echo "  copilot/copilot-instructions.md  (GitHub Copilot)"
echo ""
echo "To set up a new repo, start Claude Code in the repo — it will prompt automatically."
echo "Or manually: cp ~/.claude/docs/repo-templates/AGENTS-{type}.md ./AGENTS.md"
echo ""
echo "After editing ~/.claude/CLAUDE.md, run: ~/.claude/sync-global.sh"
echo ""
echo "Start a new Claude Code session to pick up changes. Use /skills to verify."

# Install update checker
cp "$SCRIPT_DIR/check-template-update.sh" ~/.claude/check-template-update.sh
chmod +x ~/.claude/check-template-update.sh
echo "  check-template-update.sh                     (run from any repo root)"

# Install sync script
cp "$SCRIPT_DIR/sync-global.sh" ~/.claude/sync-global.sh
chmod +x ~/.claude/sync-global.sh
